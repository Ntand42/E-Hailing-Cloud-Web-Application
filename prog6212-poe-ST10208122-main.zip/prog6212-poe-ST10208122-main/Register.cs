﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poelast3
{
    public class Register
    {
        public int RegID { get; set; }

        public string StNo { get; set; }

        public string Modcode { get; set; }

        public DateTime date_ { get; set; }

        //Constructor
        public Register(int regID, string stNo, string modcode, DateTime date_)
        {
            RegID = regID;
            StNo = stNo;
            Modcode = modcode;
            this.date_ = date_;
        }
        //Registor Method
        public void Reg()
        {
            using (SqlConnection con = Connections.GetConnection())
            {
                string strinsert = $"INSERT INTO Register" + "" +
                    $"VALUES ({RegID},'{StNo}','{Modcode}'," +
                    $"'{date_.ToString("yyyy-MM-dd")}')";
                con.Open();

                SqlCommand cmdInsert = new SqlCommand(strinsert, con);

                cmdInsert.ExecuteNonQuery();
            }
        }
    }
}

