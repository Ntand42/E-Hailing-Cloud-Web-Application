# prog6212-poe-ST10208122
prog6212-poe-ST10208122 created by GitHub Classroom
1. The first thing the user has to do is to press the play button
2. Then the application runs it will take the user to the Login form
3. The login form will ask the user to enter ausername and password
4.  The username will be ST012 and password will be VVBN.
5.  Information of these details come from database.
6.  When user succesfully logged in it will take them to the home or student project page.
7.  It will display students projects show course name, code, credits, number of weeks, start date and self study hours.
8.  Then if a user wants to add a module they click create new then it will take them to a create page.
9.  The create page will display course name, code, credits, number of weeks, start date and self study hours.
10.  Once user is done entering it they must click create.
11.  Then cick back to list it will take them back to student project page.
12.  When users are done they can click on Stats to show their graph and see number of hours spent on a project per week.
13. Once they are done they can click back to list and it can tak ethem back to the student projects.
