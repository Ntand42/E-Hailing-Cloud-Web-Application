﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poelast3
{
    public class Student
    {
        //Variables 
        public string StNo { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Password { get; set; }

        //Constructor
        public Student(string stNo, string firstName, string lastName, string password)
        {
            StNo = stNo;
            FirstName = firstName;
            LastName = lastName;
            Password = password;
        }
        //GetStudent method

        public Student()
        {

        }
        public static Student Getstudent(string studentNum)
        {
            Student st = null;
            using (SqlConnection con = Connections.GetConnection())
            {
                string strSelect = $"SELECT * FROM Student WHERE StNo ='{studentNum}'";  //Select statment for the student number
                con.Open();
                SqlCommand cmdSelect = new SqlCommand(strSelect, con);
                using (SqlDataReader rd = cmdSelect.ExecuteReader())
                {
                    while (rd.Read())
                    {
                        st = new Student(rd.GetString(0), rd.GetString(1),
                            rd.GetString(2), rd.GetString(3));
                    }
                }
            }
            return st;
        }

        //public void AllStudents()
        //{

        //    using (SqlConnection con = Connections.GetConnection())
        //    {
        //        string strInsert = $"INSERT INTO Student VALUES('{StNo}','{FirstName}','{LastName}','{Password}')";  //String that enters values 
        //        con.Open();
        //        SqlCommand cmdInsert = new SqlCommand(strInsert, con);   //Connection
        //        cmdInsert.ExecuteNonQuery();
        //    }

        //}
        public static List<Student> AllStudent()
        {
            List<Student> St = new List<Student>();
            using (SqlConnection con = Connections.GetConnection())
            {
                string strSelect = $"SELECT * FROM Student";
                SqlCommand cmdSelect = new SqlCommand(strSelect, con);
                con.Open();
                using (SqlDataReader reader = cmdSelect.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Student t = new Student((string)reader[0], (string)reader[1],
                            (string)reader[2], (string)reader[3]);

                        St.Add(t);
                    }
                }

            }
            return St;
        }


    }
}
