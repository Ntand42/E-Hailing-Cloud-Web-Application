﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poelast3
{
    public class Connections
    {
        public static SqlConnection GetConnection()  //Azure portal Connection string 
        {
            string strCon = @"Server=tcp:st10208122.database.windows.net,1433;Initial Catalog=programmingDB;Persist Security Info=False;User ID=St10208122;Password=Ntando_24;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";

            return new SqlConnection(strCon);
        }
    }
}
