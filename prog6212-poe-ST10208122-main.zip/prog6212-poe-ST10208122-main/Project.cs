﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Poelast3
{
    public class Project
    {
        public string Code { get; set; }

        public string Coursename { get; set; }

        public int Credits { get; set; }

        public int Hourclass { get; set; }

        public int NumWeeks { get; set; }

        public DateTime startDate { get; set; }

        public float Selfstudy { get; set; }

        //Constructer
        public Project(string code, string name, int credits, int hourclass, int numWeeks, DateTime Startdate)
        {
            Code = code;
            Coursename = name;
            Credits = credits;
            Hourclass = hourclass;
            NumWeeks = numWeeks;
            startDate = Startdate;
            Selfstudy = SelfHours();
        }
        /// <summary>
        /// New Construter
        /// </summary>
        //List 
        public Project()
        {

        }
        public static List<Project> proList = new List<Project>();

        //AddProject Method
        public void AddProject()
        {
            using (SqlConnection con = Connections.GetConnection())
            {
                string strInsert = $" INSERT INTO Project VALUES ('{Code}','{Coursename}',{Credits},{Hourclass},{NumWeeks},'{startDate.ToString("yyyy-MM-dd")}',{Selfstudy})";
                con.Open();
                SqlCommand cmdInsert = new SqlCommand(strInsert, con);
                cmdInsert.ExecuteNonQuery();
            }

        }
        //List for Project

        //Mthod Allprojects
        public static List<Project> AllProjects()
        {
            List<Project> lt = new List<Project>();
            using (SqlConnection con = Connections.GetConnection())
            {
                string strSelect = $"SELECT * FROM Project ";
                SqlCommand cmdselect = new SqlCommand(strSelect, con);
                con.Open();
                using (SqlDataReader reader = cmdselect.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Project l = new Project((string)reader[0], (string)reader[1],
                            (int)reader[2], (int)reader[3], (int)reader[4],
                            Convert.ToDateTime(reader[5]));

                        lt.Add(l);

                    }
                }
            }
            return lt;
        }





        //Calculation Code for Self Study Hours
        public float SelfHours()
        {
            return ((Credits * 10) / NumWeeks) - Hourclass;


        }

        //Printing Display 
        public override string ToString()
        {
            return $" Module Code: {Code} \nModule Name: {Coursename} \nNumber of Credits:{Credits} \nClass hours per week: {Hourclass} \nNumber of weeks: {NumWeeks} \nStartDate: {startDate}";
        }

        //public static List<Project> StudyRemains() =>
        //    (from p in proList
        //     where (p.Selfstudy = 
        //    )

        public class Semester
        {
            public string Module { get; set; }

            public int CurrentWeek { get; set; }


        }
        //public static List<Project> SpecificDay() =>
        //    (from p in proList
        //     where (p.Hourclass - 1) > 6
        //     select p).ToList();
    }
}

